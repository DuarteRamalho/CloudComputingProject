import os

class FileStorage:
    def __init__(self):
        self.base_path = '/app/uploads'

    def save_file(self, file, filename, user_id):
        user_folder = os.path.join(self.base_path, str(user_id))
        os.makedirs(user_folder, exist_ok=True)
        file_path = os.path.join(user_folder, filename)
        file.save(file_path)

    def get_file_path(self, filename, user_id):
        return os.path.join(self.base_path, str(user_id), filename)

    def delete_file(self, filename, user_id):
        file_path = self.get_file_path(filename, user_id)
        if os.path.exists(file_path):
            os.remove(file_path)
